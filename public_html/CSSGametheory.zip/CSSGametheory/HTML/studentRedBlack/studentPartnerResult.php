<?php
    //Connect to database
    $mysqli = require __DIR__ ."/db.php";

    // Start the session if not already started
    session_start();

    //TODO: Remove these once they are already stored in the session from another page
    $_SESSION["link_id"] = 1;
    $_SESSION["round_num"] = 1;

    //Save values from session as variables
    $link_id = $_SESSION["link_id"];
    $round_num = $_SESSION["round_num"];

    //Get this round's pairing ID
    $sql = sprintf("SELECT pairing_id
	                    FROM session_partner p
                        WHERE p.round_num = '%s' 
                            AND p.link_id = '%s'",
                    $mysqli->real_escape_string($round_num),
                    $mysqli->real_escape_string($link_id)
                    );

    $result = $mysqli->query($sql);

    $result = $result->fetch_assoc();
    $pairing_id = $result["pairing_id"];

    //Get partner's link_id
    $sql = sprintf("SELECT link_id
	                    FROM session_partner
                        WHERE pairing_id = '%s'
		                    AND link_id != '%s'",
                    $mysqli->real_escape_string($pairing_id),
                    $mysqli->real_escape_string($link_id)
                    );

    $result = $mysqli->query($sql);

    $result = $result->fetch_assoc();
    $partner_link_id = $result["link_id"];

    //Get partner's card played this round
    $sql = sprintf("SELECT card_selected
	                    FROM player_round_history
	                    WHERE link_id = '%s'
		                    AND round_num = '%s'",
                    $mysqli->real_escape_string($partner_link_id),
                    $mysqli->real_escape_string($round_num)
                    );

    $result = $mysqli->query($sql);

    $result = $result->fetch_assoc();
    $partner_card_selected = $result["card_selected"];

    //Get your card from this round
    $sql = sprintf("SELECT card_selected
	                    FROM player_round_history
	                    WHERE link_id = '%s'
		                    AND round_num = '%s'",
                    $mysqli->real_escape_string($link_id),
                    $mysqli->real_escape_string($round_num)
                    );

    $result = $mysqli->query($sql);

    $result = $result->fetch_assoc();
    $my_card_selected = $result["card_selected"];

    //Calculate and set returns
    $my_returns = 0;
    $partner_returns = 0;

    //What did you do
    if ($my_card_selected == 'RED'){
        $my_returns += 50;
    } else if ($my_card_selected == 'BLACK') {
        $partner_returns += 150;
    }

    //What did your partner do
    if ($partner_card_selected == 'RED') {
        $partner_returns += 50;
    } else if ($partner_card_selected == 'BLACK') {
        $my_returns += 150;
    }

    //Fetches your score total before this round
    $sql = sprintf("SELECT SUM(round_score) AS total
	                    FROM player_round_history
                        WHERE link_id = '%s'
		                AND round_num < '%s'",
                    $mysqli->real_escape_string($link_id),
                    $mysqli->real_escape_string($round_num)
                    );

    $result = $mysqli->query($sql);

    $result = $result->fetch_assoc();
    
    $my_previous_total_score;

    if ($result["total"] == NULL) {
        $my_previous_total_score = 0;
    } else {
        $my_previous_total_score = $result["total"];
    }

    //Fetches your partner's total before this round
    $sql = sprintf("SELECT SUM(round_score) AS total
	                    FROM player_round_history
                        WHERE link_id = '%s'
		                AND round_num < '%s'",
                    $mysqli->real_escape_string($partner_link_id),
                    $mysqli->real_escape_string($round_num)
                    );

    $result = $mysqli->query($sql);

    $result = $result->fetch_assoc();

    $partner_previous_total_score;

    if ($result["total"] == NULL) {
        $partner_previous_total_score = 0;
    } else {
        $partner_previous_total_score = $result["total"];
    }

    //Creates a vairable to store the new score total for you and your partner
    $my_total = $my_previous_total_score + $my_returns;

    $partner_total = $partner_previous_total_score + $partner_returns;

    //Updates your(user)'s score
        //Need to ensure that this does not run multiple times on refresh
    $sql = sprintf("SELECT round_score FROM player_round_history WHERE link_id = '%s' AND round_num = '%s'",
                    $mysqli->real_escape_string($link_id),
                    $mysqli->real_escape_string($round_num)
                    );
    $result = $mysqli->query($sql);
    $result = $result->fetch_assoc();
    if ($result["round_score"] == NULL) {
        $sql = sprintf("UPDATE player_round_history
	                    SET round_score = '%s'
                        WHERE link_id = '%s'
		                AND round_num = '%s'",
                    $mysqli->real_escape_string($my_returns),
                    $mysqli->real_escape_string($link_id),
                    $mysqli->real_escape_string($round_num)
                    );
        $result = $mysqli->query($sql);
    }
    
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<title></title>
	<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet" />
	<link href="/CSSGametheory/css/studentRedBlack.css" rel="stylesheet" />
</head>
<body>
<p><iframe scrolling="no" src="/CSSGametheory/HTML/header.html" style="border:none; height: 100px; width: 100%;"></iframe><!--- fix positioning with CSS ---></p>

<div id="results">
<table>
	<tbody>
		<tr>
			<td colspan="2">
			<h1 class="bottomHalf" id="roundNumHead">Round: <?php echo $round_num; ?></h1>
			<!--- make dynamic ---></td>
		</tr>
		<tr>
			<td>
			<h1 class="short">You Played</h1>
			</td>
			<td>
			<h1 class="short">Your Partner Played:</h1>
			</td>
		</tr>
		<!--- the wireframes have an off-white filter over the cards ---><!--- might be difficult to display different image depending on round info-->
		<tr>
            <?php if ($my_card_selected == 'RED'): ?>
                <td class="card"><img id="youPlayed" src="/CSSGametheory/Img/kingHearts.svg" /></td>
            <?php elseif ($my_card_selected == 'BLACK'): ?>
                <td class="card"><img id="youPlayed" src="/CSSGametheory/Img/kingSpades.svg" /></td>
            <?php endif; ?>
            <?php if ($partner_card_selected == 'RED'): ?>
                <td class="card"><img id="partnerPlayed" src="/CSSGametheory/Img/kingHearts.svg" /></td>
            <?php elseif ($partner_card_selected == 'BLACK'): ?>
                <td class="card"><img id="partnerPlayed" src="/CSSGametheory/Img/kingSpades.svg" /></td>
            <?php endif; ?>
		</tr>
        
	</tbody>
</table>
</div>
<!--- make points dynamic ---><!--- fix styling with CSS --->

<div id="roundResults">
<table>
	<tbody>
		<tr>
			<td colspan="2"><u>Returns:</u></td>
		</tr>
		<tr>
			<td><strong>You:</strong></td>
			<td><?php echo $my_returns; ?></td>
		</tr>
		<tr>
			<td><strong>Partner:</strong></td>
			<td><?php echo $partner_returns; ?></td>
		</tr>
		<tr>
		</tr>
	</tbody>
</table>
</div>

<div id="totalScores">
<table>
	<tbody>
		<tr>
			<td colspan="2"><u>Total Scores:</u></td>
		</tr>
		<tr>
			<td><strong>You:</strong></td>
			<td><?php echo $my_total; ?></td>
		</tr>
		<tr>
			<td><strong>Partner:</strong></td>
			<td><?php echo $partner_total; ?></td>
		</tr>
		<tr>
		</tr>
	</tbody>
</table>
</div>
</body>
</html>