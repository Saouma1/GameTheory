<?php
	//Connect to database
    $mysqli = require __DIR__ ."/db.php";

	// Start the session if not already started
	session_start();

	//Get data from the database
	$sqlGameCatalog = "SELECT * FROM game_catalog";

	$resultCatalog = $mysqli->query($sqlGameCatalog);
	$mysqli->close();
?>

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="/CSSGametheory/css/teacherGameSelect.css">
</head>

<body style="overflow: hidden;">
    <iframe scrolling="no" style="border:none; height: 100px; width: 100%;" src="..\header.html"></iframe>
    <div style="width: 100%; height: 100%; position: relative; display: flex; justify-content: center; align-items: center; flex-direction: column;">
        <div class="select-game">Select Game</div> <!--- would a header make more sense here? --->
        <div class="button-container">
            <div class="game-wrapper">
                <!-- PHP CODE TO FETCH DATA FROM ROWS --> <!--- thanks Chris --->
                <?php 
                    // LOOP TILL END OF DATA
                    while($rows = $resultCatalog->fetch_assoc()) {
                        $game_id = $rows['game_id'];
                        $game_title = $rows['game_title'];
                ?>
                <!--- when a teacher selects the game, create game session with that game's id --->
                <a href="..\StudentSignIn\studentLoading.php?id=<?php echo $game_id; ?>" id="gameIconLink">
                    <?php
                        if ($game_id == "1") {
                    ?>
                        <img src="/CSSGametheory/Img/RedCardBlackCard.jpeg" alt="Red Card Black Card" class="game-button" id="gameIcon" style="left: -225px;">
                    <?php
                        }
                        else if ($game_id == "2") {
                    ?>
                        <img src="/CSSGametheory/Img/WheatAndSteel.jpeg" alt="Wheat and Steel" class="game-button" style="left: 225px;">
                    <?php
                        }
                    ?>
                </a>
                <!--- header outside of link --->
                <!--- having the header outside of the link and wide enough seems to be what causes the icons to be side by side ?? -->
                <?php
                        if ($game_id == "1") {
                    ?>
                        <h3 class="game-title" style="width: 350px;" id="gameOneTitle"><?php echo $game_title; ?></h3>
                    <?php
                        }
                        else if ($game_id == "2") {
                    ?>
                        <h3 class="game-title" style="width: 350px;" id="gameTwoTitle"><?php echo $game_title; ?></h3>
                    <?php
                        }
                    ?>
            
                <!--- close the while loop --->
                <?php
                    }
                ?>
                <script>
                    // use class to put all games on the same top px
                    // icons are side by side without doing id-specific styling but for some reason the headers aren't behaving the same wayw
                    const buttons = document.getElementsByClassName("game-button");
                    const titles = document.getElementsByClassName("game-title"); // always same number of titles and icons
                    for (let i = 0; i < buttons.length; i++) {
                        buttons[i].style.position = "absolute";
                        buttons[i].style.top = "0px";
                        titles[i].style.position = "relative";
                    }
                    
                    // I recognize that this needs to be optimized/made dymaic but I can't figure out how to do it without losing my mind
                        // because the header and image widths are somehow linked together
                        // if I move the header around via loop, the images get super narrow and I really have no clue why
                            // the code always does exactly what we tell it to do but who knows why this is what this means
                    
                    let gameOneTitle = document.getElementById("gameOneTitle");
                    let gameTwoTitle = document.getElementById("gameTwoTitle");
                    gameOneTitle.style.top = "300px";
                    gameTwoTitle.style.top = "242px"; // somehow this puts them on the same level
                    gameOneTitle.style.left = "-125px";
                    gameTwoTitle.style.left = "340px";
                </script>
            </div>
        </div>
    </div>
</body>
</html>