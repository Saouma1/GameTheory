<?php

    $mysqli = require __DIR__ ."/db.php";

    //Required variable declaration
    $session_id;
    $student_id;
    $first_nm;
    $last_nm;
    $email;
    $num_rb_games;
    $high_score;
    $low_score;
    $rb_point_average;

    //Parsing the game_session_id from the URL
        session_start();
        //print_r($_SESSION);
        $var = $_SERVER['QUERY_STRING'];
        //print_r($var);
        $parts = explode('=', $var);
        if (count($parts) > 1) {
            $session_id = $parts[1];
        } else {
            echo'No "=" found in the string.';
        }
        //print_r($game_session_id);
    
    //Save the Game Date to a variable
        $sql = sprintf("SELECT student_id FROM session_instance
                            WHERE session_id = '%s';",
                                $mysqli->real_escape_string($session_id));
                                $result = $mysqli->query($sql);

        if ($result) {
            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $student_id = $row['student_id'];
            } else {
                $student_id = NULL;
            }
        } else {
            $create_dt = "Error: " . $mysqli->error;
        }
        $result->close();

    //Save the First Name to a variable
        $sql = sprintf("SELECT first_nm FROM student_profile
                            WHERE student_id = '%s';",
                                $mysqli->real_escape_string($student_id));
                                $result = $mysqli->query($sql);

        if ($result) {
            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $first_nm = $row['first_nm'];
            } else {
                $first_nm = "There is no value for this with the ID of: " . $session_id;
            }
        } else {
            $first_nm = "Error: " . $mysqli->error;
        }
        $result->close();

    //Save the Last Name to a variable
        $sql = sprintf("SELECT last_nm FROM student_profile
                            WHERE student_id = '%s';",
                                $mysqli->real_escape_string($student_id));
                                $result = $mysqli->query($sql);

        if ($result) {
            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $last_nm = $row['last_nm'];
            } else {
                $last_nm = "There is no value for this with the ID of: " . $session_id;
            }
        } else {
            $last_nm = "Error: " . $mysqli->error;
        }
        $result->close();

    //Save the Email to a variable
        $sql = sprintf("SELECT email FROM student_profile
                            WHERE student_id = '%s';",
                                $mysqli->real_escape_string($student_id));
                                $result = $mysqli->query($sql);

        if ($result) {
            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $email = $row['email'];
            } else {
                $email = "There is no value for this with the ID of: " . $session_id;
            }
        } else {
            $email = "Error: " . $mysqli->error;
        }
        $result->close();
    
    //Save the Number of RB Games Played to a variable
        $sql = sprintf("SELECT COUNT(game_session_id) AS num_games 
                            FROM student_game_session
                            WHERE session_id = '%s';",
                                $mysqli->real_escape_string($session_id));
                                $result = $mysqli->query($sql);

        if ($result) {
            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $num_rb_games = $row['num_games'];
            } else {
                $num_rb_games = "There is no value for this with the ID of: " . $session_id;
            }
        } else {
            $num_rb_games = "Error: " . $mysqli->error;
        }
        $result->close();

    //Save the high score to a variable
        $sql = sprintf("SELECT user_id, session_id, SUM(round_score) AS total_score
                            FROM player_round_history
                            WHERE user_id = '%s'
                            GROUP BY user_id, session_id
                            ORDER BY total_score DESC
                            LIMIT 1;",
                                $mysqli->real_escape_string($student_id));
                                $result = $mysqli->query($sql);

        if ($result) {
            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $high_score = $row['total_score'];
            } else {
                $high_score = "There is no value for this with the ID of: " . $session_id;
            }
        } else {
            $high_score = "Error: " . $mysqli->error;
        }
        $result->close();

    //Save the high score to a variable
        $sql = sprintf("SELECT user_id, session_id, SUM(round_score) AS total_score
                            FROM player_round_history
                            WHERE user_id = '%s'
                            GROUP BY user_id, session_id
                            ORDER BY total_score ASC
                            LIMIT 1;",
                                $mysqli->real_escape_string($student_id));
                                $result = $mysqli->query($sql);

        if ($result) {
            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $low_score = $row['total_score'];
            } else {
                $low_score = "There is no value for this with the ID of: " . $session_id;
            }
        } else {
            $low_score = "Error: " . $mysqli->error;
        }
        $result->close();

    //Save the game point average to a variable
        $sql = sprintf("SELECT user_id, session_id, SUM(round_score) AS average_score
                            FROM player_round_history
                            WHERE user_id = '%s';",
                                $mysqli->real_escape_string($student_id));
                                $result = $mysqli->query($sql);

        if ($result) {
            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $rb_point_average = $row['average_score'];
                if ($num_rb_games > 0) {
                    $rb_point_average = $rb_point_average/$num_rb_games;
                } else {
                    $rb_point_average = "Student has not played any games";
                }
                
            } else {
                $rb_point_average = "There is no value for this with the ID of: " . $session_id;
            }
        } else {
            $rb_point_average = "Error: " . $mysqli->error;
        }
        $result->close();

?>

<!DOCTYPE html>
<html>
<head><meta charset="utf-8">
	<title>Student View</title>
	<link href="/CSSGametheory/css/admin.css" rel="stylesheet" /><script src="/CSSGametheory/JavaScript/studentRetrieve.js" defer></script><script src="/CSSGametheory/JavaScript/createGame.js" defer></script><!--- makes sure the values are in localStorage --->
</head>
<body>
<p><iframe scrolling="no" src="/CSSGametheory/HTML/header.html" style="border:none;" width="100%"></iframe></p>

<h1 id="studentHeader">Student (<?php echo $first_nm; ?> <?php echo $last_nm; ?>)</h1>

<div id="userInfo">First Name: <?php echo $first_nm; ?><br />
Last Name: <?php echo $last_nm; ?><br />
Email: <?php echo $email; ?></div>

<p></p>

<div id="redBlackInfo">Number of Red/Black Games Played: <?php echo $num_rb_games; ?><br />
Highest Final Score: <?php echo $high_score; ?><br />
Lowest Final Score: <?php echo $low_score; ?><br />
Game Point Average: <?php echo $rb_point_average; ?></div>

<p></p>

<p></p>

<div id="wheatSteelInfo">Number of Wheat &amp; Steel Games Played: <span id="wheatSteelNum">0</span><br />
Highest Total Wheat Production: <span id="wheatHigh">0</span><br />
Wheat Consumption Goals Met: <span id="wheatGoalNum">0</span><br />
Highest Total Steel Production: <span id="steelHigh">0</span><br />
Steel Consumption Goals Met: <span id="steelGoalNum">0</span></div>

<p><br />
<!--- TODO: create footer with iframe, making sure to include target=_blank attribute ---></p>

<p></p>

<table id="links">
	<tbody>
		<tr>
			<td><a href="/CSSGametheory/HTML/admin/allStudents.html">All Students</a></td>
			<td><a href="/CSSGametheory/HTML/admin/index.html">Back to Home</a> <!--admin index--></td>
			<td><a href="/CSSGametheory/HTML/admin/allGames.php">All Games</a></td>
		</tr>
	</tbody>
</table>
</body>
</html>