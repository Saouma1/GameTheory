<?php
    session_start();
    print_r($_SESSION);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="/CSSGametheory/css/student.css" rel="stylesheet" />
    <title>Enter Game Code</title>
</head>
    <iframe scrolling="no" style="border:none;" width="100%" src="/CSSGametheory/HTML/header.html"></iframe>
    <body>
        <br> <br> <br>
        <h1 id="gameHeader">{Game Name}</h1>
        <h2 id="gameName">Enter Code to Join Game Room</h2>
        <div id ="codeInput"> <!--- form --->
            <form method = "POST" action="landingPage.html">
                <input type="text" maxlength="6" size="12" id="gameCode" name="gameCode"> 
                <br>
                <p id="codeDashes">______</p>
                <br> <br>
                <input id="codeSubmit" type="submit" value="Submit">
            </form>
            <br>
            <?php if (isset($_SESSION["user_id"])): ?>
                <p>You are logged in.</p>
            <?php else: ?>
                <p>You are not logged in.</p>
            <?php endif; ?>
        </div>
    </body>
</html>