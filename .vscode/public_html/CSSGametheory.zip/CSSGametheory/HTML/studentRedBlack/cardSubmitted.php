<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["submit"])) {
        $buttonValue = $_POST["submit"];
        //Connect to database
        $mysqli = require __DIR__ ."/db.php";

        // Start the session if not already started
        session_start();
        $link_id = $_SESSION["link_id"];
        $game_session_id = $_SESSION["game_session_id"];
        $round_num = $_SESSION["round_num"];
        $session_id = $_SESSION["session_id"];
        $user_id = $_SESSION["user_id"];

        //echo 'Link: '. $link_id . ' GS ID: ' . $game_session_id . ' Round Num: ' . $round_num .' Session ID: '. $session_id .' User ID: '. $user_id;

        //Add to play history
        $sql = sprintf("INSERT INTO player_round_history (user_id, session_id, link_id, round_num, card_selected)
	                        VALUES ('%s', 
			                        '%s', 
                                    '%s', 
                                    '%s', 
                                    '%s' 
                                    )", 
                        $mysqli->real_escape_string($user_id),
                        $mysqli->real_escape_string($session_id),
                        $mysqli->real_escape_string($link_id),
                        $mysqli->real_escape_string($round_num),
                        $mysqli->real_escape_string($buttonValue)
                    );

        $result = $mysqli->query($sql);

        //echo" Record was submitted "; 
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <link rel="stylesheet" href="/CSSGametheory/css/studentRedBlack.css">
</head>
<body>
  <iframe scrolling="no" style="border:none; height: 100px; width: 100%;" src="/CSSGametheory/HTML/header.html"></iframe>
    
  <!--- meant to be brief --->
    <div id="cards">
        <h1><u>You Have Selected:</u></h1>
        <input type="hidden" value = <?php echo htmlspecialchars($buttonValue);?> id="cardType"> 
        <!--- the wireframes have an off-white filter over the cards --->
        <img src="/CSSGametheory/Img/kingHearts.svg" id="chosenCard" alt="image of red or black card">
    </div>
    <div id="pleaseWait">
        <table>
            <tr>
                <td><h2><strong>Please wait until card selection has concluded.</strong></h2></td>
            </tr>
            <tr>
                <td>
                    <br>
                    <div class="loader"></div>
                </td>
            </tr>
        </table>
    </div>
</body>
<script src="/CSSGametheory/JavaScript/cardRetrieve.js" defer></script>
</html>